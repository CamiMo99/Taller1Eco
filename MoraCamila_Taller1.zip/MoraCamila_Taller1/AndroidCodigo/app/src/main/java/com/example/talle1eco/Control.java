package com.example.talle1eco;

import androidx.appcompat.app.AppCompatActivity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import java.util.Observable;
import java.util.Observer;

public class Control extends AppCompatActivity implements Observer {

    private ImageButton up;
    private ImageButton down;
    private ImageButton shoot;
    private ImageButton returncontrol;
    private ImageButton pausa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE);

        final Comunication conexion = Comunication.getRef();
        conexion.addObserver(this);

        up =findViewById(R.id.btn_up);
        down =findViewById(R.id.btn_down);
        shoot =findViewById(R.id.btn_shoot);



        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conexion.enviar("I");
            }
        });

        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conexion.enviar("D");
            }
        });

        shoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conexion.enviar("S");
            }
        });
    }

    @Override
    public void update(Observable o, Object arg) {

    }
}
