package com.example.talle1eco;

import android.view.View;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Observable;

public class Comunication  extends Observable implements Runnable {

    private String ipServidor = "";
    private Boolean conectado ;

    private Socket socket;
    private DataInputStream entrada;
    private DataOutputStream salida;

    private static  Comunication ref;

    public  Comunication (){
        this.conectado = false;

    }

    public static Comunication  getRef(){
        if(ref ==null ){
            ref = new Comunication();
        }
        return ref;
    }

    public void crearConexion (String ip){
        this.ipServidor = ip;
        Thread t = new Thread(ref);
        t.start();
    }

    public void run() {
        while(true) {
            try {
                if(conectado==false) {

                    socket = new Socket(InetAddress.getByName("192.168.0.11"), 5000);
                    entrada = new DataInputStream(socket.getInputStream());
                    salida = new DataOutputStream(socket.getOutputStream());
                    conectado = true;
                } else {
                    recibir();
                    Thread.sleep(33);
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void recibir() throws IOException {
        String mensaje = entrada.readUTF();
        setChanged();
        notifyObservers(mensaje);
        clearChanged();
    }

    public void enviar(final String id) {
        if(socket != null && socket.isConnected() && salida != null) {
            new Thread(new Runnable() {
                public void run() {
                    try {
                        salida.writeUTF(id);
                        salida.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }

}
