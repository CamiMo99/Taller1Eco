package pexganza;

import processing.core.PApplet;

public class Main extends PApplet{
	
	//ESTE TALLER LO REALICE CON AYUDA DE DANIEL GAMBOA Y LINA VASQUEZ
	private Logica log;

	public static void main(String[] args) {
		PApplet.main("pexganza.Main");

	}
	
	public void settings() {
		size(1200,700);
	}
	
	public void setup() {
		log = new Logica(this);
	}
	
	public void draw() {
		log.pintar();
	}
	

}
