package pexganza;

import java.util.ArrayList;
import java.util.Random;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

public class Fantasma extends Thread {

	private PApplet app;

	public int fila;
	private int y;
	private int x = 38;
	private PImage gosfix;
	private Logica logi;

	public Fantasma(PApplet p, int i) {

		this.app = p;
		
		Random rnd = new Random();
		int random = rnd.nextInt(3) +1;
		switch (random) {
		case 1:

			this.gosfix = app.loadImage("pexganza1-8.png");
			break;
		case 2:

			this.gosfix = app.loadImage("pexganza2-8.png");
			break;
			
		case 3:

			this.gosfix = app.loadImage("pexganza3-8.png");
			break;
		}
		
		
		this.fila = i;

		switch (fila) {

		case 1:
			this.x = 100;
			break;

		case 2:
			this.x = 280;
			break;

		case 3:
			this.x = 450;
			break;

		case 4:

			this.x = 640;
			break;
		}
		 app.image(gosfix, x, y);
	}

	// hilo
	public void run() {
		while (true) {
			try {
				sleep(20);
				this.y = this.y + 3;

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void pintar() {
		app.image(gosfix, x, y);

	}

}
