package pexganza;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import processing.core.PApplet;
import processing.core.PImage;

public class Logica implements Observer {
	private PApplet app;

	// imgagenes
	private PImage yakitory1, juego, inicio, gameOver;

	private int pantalla;
	private int yakitoryY = 144;
	private ArrayList<ArrayList> fantasmas;

	private ControlS conexion;
	private long start;
	private int f;
	private long Millis;

	private long startJuego;

	private long tiempo;

	public Logica(PApplet app) {

		this.app = app;
		pantalla = 1;

		conexion = ControlS.iniciarConexion();
		conexion.addObserver(this);

		// ARREGLOS ENEMIGOS
		fantasmas = new ArrayList<ArrayList>();

		// YAKITORYS
		yakitory1 = app.loadImage("yakitory1-8.png");

		// PANTALLAS
		inicio = app.loadImage("inicio.png");
		juego = app.loadImage("juego.png");
		gameOver = app.loadImage("gameover.png");

		start = System.currentTimeMillis();
		
		//lini, en donde se le dan las posiciones pa que de play?
	}

	public void cargarFantasmas() {

		Random rnd = new Random();
		int cantidadEnemigos = rnd.nextInt(5) + 1;

		ArrayList<Fantasma> goxfisFila = new ArrayList<Fantasma>();

		ArrayList<Integer> posiciones = new ArrayList<Integer>();
		posiciones.add(1);
		posiciones.add(2);
		posiciones.add(3);
		posiciones.add(4);
		posiciones.add(5);
		posiciones.add(6);

		Collections.shuffle(posiciones);

		for (int i = 0; i < cantidadEnemigos; i++) {

			Fantasma a = new Fantasma(app, posiciones.get(i));
			a.start();
			goxfisFila.add(a);

		}

		fantasmas.add(goxfisFila);
		start = System.currentTimeMillis();
		int x = 0;
		x++;

	}

//DRAW
	public void pintar() {

		// System.out.println("pantalla numero: " + pantalla);
		switch (pantalla) {

		case 1:
			app.image(inicio, 0, 0);

			break;

		case 2:

			app.image(juego, 0, 0);

			app.text((System.currentTimeMillis() - startJuego) / 1000 + "", 60, 410);
			System.out.println("pantalla = 2");

			app.image(yakitory1, 10, yakitoryY);

			Millis = System.currentTimeMillis();
			long time = Millis - start;
			if (time > 2000) {
				cargarFantasmas();

			}

			for (int i = 0; i < fantasmas.size(); i++) {

				ArrayList<Fantasma> listGoxfis = fantasmas.get(i);

				for (int j = 0; j < listGoxfis.size(); j++) {

					((Fantasma) listGoxfis.get(j)).pintar();

					int yEnemy = ((Fantasma) listGoxfis.get(j)).getY();

					int xEnemy = ((Fantasma) listGoxfis.get(j)).getX();

					System.out.println(yakitoryY);
					System.out.println(yEnemy);
					System.out.println(xEnemy);

					//VALIDACIONNNNNNNNNNNN
					if ((yEnemy > 500 && yEnemy < 657) && ((yakitoryY >= xEnemy && yakitoryY <= xEnemy + 80)
							|| (yakitoryY + 100 >= xEnemy && yakitoryY + 100 <= xEnemy + 80))) {

						pantalla = 3;
						tiempo = System.currentTimeMillis();
					}
				}
			}

			break;

		case 3:
			app.image(gameOver, 0, 0);
			app.text("Tiempo: " + (tiempo - startJuego) / 1000, 550, 400);
			break;
		}
		app.fill(0);
	}

//MOUSEPRESSED	

	@Override
	public void update(Observable o, Object arg) {

		String mensaje = (String) arg;

		if (mensaje.matches("S") && pantalla == 1) {
			System.out.println("deberia pasar a pantalla2");
			System.out.println(pantalla + "pantalla 2");
			pantalla = 2;
			startJuego = System.currentTimeMillis();
		}
//ups
		if (pantalla == 2) {
			if (mensaje.matches("D") && yakitoryY <= 902) {
				yakitoryY = yakitoryY + 162;
			}
			if (mensaje.matches("I") && yakitoryY >= 306) {
				yakitoryY = yakitoryY - 162;
			}

		}

		if (pantalla == 3 && mensaje.matches("F")) {

			fantasmas.clear();
			pantalla = 2;

			startJuego = System.currentTimeMillis();
		}

	}

}