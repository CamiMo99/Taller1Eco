
package pexganza;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.CharBuffer;
import java.util.Observable;

public class ControlS extends Observable implements Readable {
	private Socket socket;
	private ServerSocket server;
	private DataOutputStream salida;
	private DataInputStream entrada;
	boolean conectado;
	private String dato;
	private static InetAddress ip;
	private static ControlS ref;

	public ControlS() {
		conectado = false;
		try {
			ip=InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			System.out.println("ip");
			e.printStackTrace();
		}
	}

	public static ControlS iniciarConexion() {
		if (ref == null) {
			ref = new ControlS();
			Thread t = new Thread();
			t.start();
		}
		return ref;
	}

	public static InetAddress getIp() {
		return ip;
	}

	public void run() {
		while (true) {
			try {
				if (!conectado) {
					server = new ServerSocket(5000);
					System.out.println("Esperando cliente...");
					socket = server.accept();
					System.out.println("Cliente aceptado");
					entrada = new DataInputStream(socket.getInputStream());
					salida = new DataOutputStream(socket.getOutputStream());
					conectado = true;
				} else {

					entrada();
					Thread.sleep(33);
				}

			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void entrada() throws IOException {
		String recibido = entrada.readUTF();

		setChanged();
		notifyObservers(recibido);
		System.out.println("Mensaje notificado: " + recibido);
		clearChanged();

	}

	public void enviar(String mensaje) {

		try {
			salida.writeUTF(dato);
			salida.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public int read(CharBuffer cb) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

}
